Client * prevt(Client *c);
static void pushup(const Arg *arg);
static void pushdown(const Arg *arg);


static void unfloatvisible(const Arg *arg);


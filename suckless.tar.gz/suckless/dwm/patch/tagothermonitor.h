#if IPC_PATCH || DWMC_PATCH
static void tagnextmonex(const Arg *arg);
static void tagprevmonex(const Arg *arg);
#endif // IPC_PATCH | DWMC_PATCH

static void tagnextmon(const Arg *arg);
static void tagprevmon(const Arg *arg);
static void tagothermon(const Arg *arg, int dir);


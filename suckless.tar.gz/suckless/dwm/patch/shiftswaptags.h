static void shiftswaptags(const Arg *arg);

static int width_tags(Bar *bar, BarArg *a);
static int draw_tags(Bar *bar, BarArg *a);
static int click_tags(Bar *bar, Arg *arg, BarArg *a);
static int hover_tags(Bar *bar, BarArg *a, XMotionEvent *ev);

static void removescratch(const Arg *arg);
static void setscratch(const Arg *arg);
static void spawnscratch(const Arg *arg);
static void togglescratch(const Arg *arg);
